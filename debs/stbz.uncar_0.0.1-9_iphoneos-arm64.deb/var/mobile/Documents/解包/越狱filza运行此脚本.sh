#!/bin/bash
# https://qi-ting-zhang.github.io/sileo/

car_file="Assets.car"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
output_folder="$script_dir/少年宫"
bubble_folder="$output_folder/气泡文件"

mkdir -p "$bubble_folder"

if [ -e "$car_file" ]; then
    uncar "$car_file" "$output_folder"
    echo "初步解包完成！@达康书记亲自解压"
    
    find "$output_folder" -type f -name 'ChatRoom*' | while read -r file; do
        base_name=$(basename "$file")
        cleaned_name=$(echo "$base_name" | sed 's/-[0-9]\{2,3\}-[0-9]\{2,3\}-\(@[0-9]x\)/\1/')
        mv "$file" "$bubble_folder/$cleaned_name"
    done
    
    echo "气泡提取完成！已保存至少年宫由孙连城看管"
else
    echo "错误：文件 $car_file 不存在。"
fi