#!/usr/bin/env fish
#你看，又急https://qi-ting-zhang.github.io/sileo/
set car_file "Assets.car"

set script_dir (dirname $0)

set output_folder $script_dir

if test -e "$car_file"
    uncar "$car_file" 解包结果 "$output_folder"
    echo "解包完成！"
else
    echo "错误：文件 $car_file 不存在。"
end